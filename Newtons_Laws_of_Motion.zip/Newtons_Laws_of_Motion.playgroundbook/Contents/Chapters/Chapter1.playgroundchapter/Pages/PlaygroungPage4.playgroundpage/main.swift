/*:
 # [Newton's](glossary://IssacNewton) Third Law of Motion
  _ _ _
 [Newton's](glossary://IssacNewton) third law states, for every action, there is an equal and opposite reaction. This means that there is a pair of forces acting on the two interacting objects in every interaction. Both of these 2 forces are equivalent to each other.
  
 ### Rocket Example- AR Simulation
  
  On the right, start the AR simulation and launch the rocket. Observe how the rocket is launching up.
  
  ![Rocket](RocketNewton.jpg)
  
  During the simulation, the rocket was going up and the exhaust flow was being pushed down. This is a perfect example of [Newton's](glossary://IssacNewton) third law, the rocket's exhaust pushes down and the thrust from the exhaust is created as a result of an equal and opposite reaction force upward.
 ### Pop Quiz
  **Finish the phrase, every action has an ___ and ___ reaction**
  * **1-** Equal and opposite
  * **2-** equal and equal
  * **3-** down and up
  * **4-** opposite and forward
  
  **How does [Newton's](glossary://IssacNewton) third law apply to a boat?**
  * **1-** Water gets pushed forward with the boat
  * **2-** Water gets pushed backwards and the boat moves forward
  * **3-** The boat is propelled forward since the tides are are moving forward
  * **4-** The boat stays in place and moves with paddles.
  ### Reminders
  - To reset rocket reset AR simulation
  - The rocket image is used to explain Newton's third law, the image can be found [here](https://www.quora.com/Is-the-working-of-a-rocket-based-on-Newtons-third-law-of-motion)
 - If the prompt to move iPad across plane does not show up, please repeat the steps from the previous pages
 */
let question1Anwser = /*#-editable-code number of repetitions*/"blank"/*#-end-editable-code*/
let question2Anwser = /*#-editable-code number of repetitions*/"blank"/*#-end-editable-code*/



//#-hidden-code
import PlaygroundSupport
import UIKit
import RealityKit
import ARKit

if (question1Anwser=="2"&&question2Anwser=="1"){
    print("Your anwsers are correct!")
}

let arView = ARView(frame:.infinite, cameraMode: .ar, automaticallyConfigureSession: true)

let initialize = ARWorldTrackingConfiguration()
initialize.planeDetection = .horizontal
initialize.isLightEstimationEnabled = true

let tutorialAR = ARCoachingOverlayView()
tutorialAR.session = arView.session
tutorialAR.translatesAutoresizingMaskIntoConstraints = false
tutorialAR.activatesAutomatically = true
arView.addSubview(tutorialAR)

NSLayoutConstraint.activate([
    tutorialAR.centerXAnchor.constraint(equalTo: arView.centerXAnchor),
    tutorialAR.centerYAnchor.constraint(equalTo: arView.centerYAnchor),
    tutorialAR.widthAnchor.constraint(equalTo: arView.widthAnchor),
    tutorialAR.heightAnchor.constraint(equalTo: arView.heightAnchor)])

let realityFile = Bundle.main.url(forResource: "rocketLaunchModel", withExtension: "reality")
let boncyBallsScene = try! Entity.load(contentsOf: realityFile!)

let anchor = AnchorEntity(plane: .horizontal)
anchor.addChild(boncyBallsScene)
anchor.scale = [1,1,1]

arView.contentScaleFactor = 0.7
arView.scene.addAnchor(anchor)
arView.session.run(initialize)

NotificationCenter.default.addObserver(forName: UIApplication.didReceiveMemoryWarningNotification, object: nil, queue: nil) {
    _ in arView.contentScaleFactor = max(arView.contentScaleFactor, 0.05)
}



PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = arView
PlaygroundPage.current.wantsFullScreenLiveView = true

//#-end-hidden-code
