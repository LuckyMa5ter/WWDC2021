/*:
 # [Newton's](glossary://IssacNewton) First Law of Motion
 _ _ _
 [Newton's](glossary://IssacNewton) First law of motion states, an object in motion will stay in motion and an
  object at rest will remain at rest unless acted upon by another force.

  ### Bouncy Ball- Activity
  **Please start the bouncy ball example on the right**
  **Experiment for a few minutes and then report back here**
  
  The bouncy ball on the right perfectly shows [Newton's](glossary://IssacNewton) first law in action.
  During the AR experience, you could turn [gravity](glossary://Gravity) on and off. You may have
  noticed that the ball's actions were utterly different under both circumstances.
  This is because [gravity](glossary://Gravity) is a force acting upon the ball.
  
  Without [gravity](glossary://Gravity), the ball would remain at rest since there would be no forces acting upon it.
 
  However, when you touched the ball, you gave it an initial velocity upwards in zero [gravity](glossary://Gravity) circumstances. This results in the ball continuously moving upwards since no forces are acting upon it. This proves that without any force, an object will stay at rest or stay in motion.
 
 When [gravity](glossary://Gravity) was present, the ball fell since a force acted upon the ball. This shows that an object is unable to stay at rest or in motion when forces are present.
  

 ### Pop Quiz
  **If an object is in space(zero [gravity](glossary://Gravity)) and is moving forward, will it stop?**
  * **1-** Yes because everything that starts moving has to stop.
  * **2-** No because there is no force acting upon the object.
  * **3-** No because it has thrusters pushing it forward.
  * **4-** Yes because [gravity](glossary://Gravity) is bringing it down to the surface of earth.
  
  **If an object is ____, then it won't move until a force is acted upon it.**
  * **1-** at rest
  * **2-** in motion
  
  
  **Why don't we drift off into space from earth?**
  * **1-** The earth's atmosphere prevents us from going into space
  * **2-** We have high tech technology that keeps us from drifing off
  * **3-** Forces such as [gravity](glossary://Gravity) are always being acted upon us
  
  ### Reminders
  - Check to see if your anwsers are correct, by clicking on the sign in the AR experience
  - Tap the ball to bounce it
  - Once you are finished move onto the next page
 - If the prompt to move iPad across plane does not show up, please repeat the steps from the previous pages
 */
let question1Anwser = /*#-editable-code number of repetitions*/"blank"/*#-end-editable-code*/
let question2Anwser = /*#-editable-code number of repetitions*/"blank"/*#-end-editable-code*/
let question3Anwser = /*#-editable-code number of repetitions*/"blank"/*#-end-editable-code*/

//#-hidden-code
import PlaygroundSupport
import UIKit
import RealityKit
import ARKit

if (question1Anwser=="2"&&question2Anwser=="1"&&question3Anwser=="3"){
    print("Your anwsers are correct")
}

let arView = ARView(frame:.infinite, cameraMode: .ar, automaticallyConfigureSession: true)

let initialize = ARWorldTrackingConfiguration()
initialize.planeDetection = .horizontal
initialize.isLightEstimationEnabled = true

let tutorialAR = ARCoachingOverlayView()
tutorialAR.session = arView.session
tutorialAR.translatesAutoresizingMaskIntoConstraints = false
tutorialAR.activatesAutomatically = true
arView.addSubview(tutorialAR)

NSLayoutConstraint.activate([
    tutorialAR.centerXAnchor.constraint(equalTo: arView.centerXAnchor),
    tutorialAR.centerYAnchor.constraint(equalTo: arView.centerYAnchor),
    tutorialAR.widthAnchor.constraint(equalTo: arView.widthAnchor),
    tutorialAR.heightAnchor.constraint(equalTo: arView.heightAnchor)])

let realityFile = Bundle.main.url(forResource: "Intro", withExtension: "reality")
let boncyBallsScene = try! Entity.load(contentsOf: realityFile!)

let anchor = AnchorEntity(plane: .horizontal)
anchor.addChild(boncyBallsScene)
anchor.scale = [1,1,1]

arView.contentScaleFactor = 0.7
arView.scene.addAnchor(anchor)
arView.session.run(initialize)

NotificationCenter.default.addObserver(forName: UIApplication.didReceiveMemoryWarningNotification, object: nil, queue: nil) {
    _ in arView.contentScaleFactor = max(arView.contentScaleFactor, 0.05)
}



PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = arView
PlaygroundPage.current.wantsFullScreenLiveView = true

//#-end-hidden-code
