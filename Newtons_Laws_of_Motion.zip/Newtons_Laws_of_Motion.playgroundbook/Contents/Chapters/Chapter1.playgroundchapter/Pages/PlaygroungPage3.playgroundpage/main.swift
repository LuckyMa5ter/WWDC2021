/*:
 # [Newton's](glossary://IssacNewton) Second Law of Motion
 _ _ _
 Before we get into [Newton's](glossary://IssacNewton) second law, we need to understand what force is.
  
  Force is the result of interactions. Whenever objects interact with each other, there is a force upon each of the objects. When the interaction ceases, the objects no longer experience the force. Force can easily be found with an object's [mass](glossary://Mass) and [acceleration](glossary://Acceleration).
  
  **[Newton's](glossary://IssacNewton) Second Law**
  
  [Newton's](glossary://IssacNewton) Second Law is the relationship between the net force and the [acceleration](glossary://Acceleration) of an object.
  
  Equation:
  
  Force = [mass](glossary://Mass) x [acceleration](glossary://Acceleration)
  
  or
  
  F = m x a
  
  - Note:
  If multiple forces are acting on the objects, then F is the net force on that object.
 
 
 ### Soccer- AR Simulation
 On the right, start the AR simulation and click to kick the soccer ball. Now use the arrows on the right to increase the amount of force the ball is being kicked with. You may notice that increasing the force increases the acceleration of the ball. This proves the equation F=mxa works.
 
 
 ### Pop Quiz!
 **If an object has a [mass](glossary://Mass) of 10.2kg and is accelerating at 23m/s^2 per hour, what is the force?**
 
 **If an object has a force of 30 N and is accelerating at 5m/s^2 what is the [mass](glossary://Mass) of the object?**

 
 **PLEASE EXCLUDE ALL UNITS OF MEASUREMENTS WHILE ANSWERING QUESTIONS**
 
 ### Reminders
 - If the prompt to move iPad across plane does not show up, please repeat the steps from the previous pages
  */

let question1Anwser = /*#-editable-code number of repetitions*/"force"/*#-end-editable-code*/
let question2Anwser = /*#-editable-code number of repetitions*/"mass"/*#-end-editable-code*/



//#-hidden-code
import PlaygroundSupport
import UIKit
import RealityKit
import ARKit

if (question1Anwser=="234.6"&&question2Anwser=="6"){
    print("Your anwsers are correct")
}

let arView = ARView(frame:.infinite, cameraMode: .ar, automaticallyConfigureSession: true)

let initialize = ARWorldTrackingConfiguration()
initialize.planeDetection = .horizontal
initialize.isLightEstimationEnabled = true

let tutorialAR = ARCoachingOverlayView()
tutorialAR.session = arView.session
tutorialAR.translatesAutoresizingMaskIntoConstraints = false
tutorialAR.activatesAutomatically = true
arView.addSubview(tutorialAR)

NSLayoutConstraint.activate([
    tutorialAR.centerXAnchor.constraint(equalTo: arView.centerXAnchor),
    tutorialAR.centerYAnchor.constraint(equalTo: arView.centerYAnchor),
    tutorialAR.widthAnchor.constraint(equalTo: arView.widthAnchor),
    tutorialAR.heightAnchor.constraint(equalTo: arView.heightAnchor)])

let realityFile = Bundle.main.url(forResource: "RealSoccer", withExtension: "reality")
let boncyBallsScene = try! Entity.load(contentsOf: realityFile!)

let anchor = AnchorEntity(plane: .horizontal)
anchor.addChild(boncyBallsScene)
anchor.scale = [1,1,1]

arView.contentScaleFactor = 0.7
arView.scene.addAnchor(anchor)
arView.session.run(initialize)

NotificationCenter.default.addObserver(forName: UIApplication.didReceiveMemoryWarningNotification, object: nil, queue: nil) {
    _ in arView.contentScaleFactor = max(arView.contentScaleFactor, 0.05)
}



PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = arView
PlaygroundPage.current.wantsFullScreenLiveView = true

//#-end-hidden-code
