//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code
/*:
 # An Introduction to Newtons's Laws of Motion!
 
 _ _ _
 Welcome! In this book, you will be learning about Sir [Isaac Newton's](glossary://IssacNewton) laws of motion!
  * * *
  [Newton's](glossary://IssacNewton) laws of motion are 3 laws that define the relationship between the movement of an object and all the [forces](glossary://force) being acted upon it. This book teaches you about these 3 laws and provides real world AR examples to grasp a better understanding of these concepts!
  ### Now Observe!
  The air hockey on the right incorporates all 3 laws of motion. Play around with it for
  a little while and observe how it functions.
  

   
  ### Reminders
  - Use your finger to interact with the puck
  - Make observations
  - Restart the AR simulation to reset the placement of your puck
  - When finished, move onto the next page
  - If the prompt to move the ipad across plane does not show up, please reset the playground book
 */
//#-hidden-code
import PlaygroundSupport
import UIKit
import RealityKit
import ARKit


let arView = ARView(frame:.infinite, cameraMode: .ar, automaticallyConfigureSession: true)

let initialize = ARWorldTrackingConfiguration()
initialize.planeDetection = .horizontal
initialize.isLightEstimationEnabled = true

let tutorialAR = ARCoachingOverlayView()
tutorialAR.session = arView.session
tutorialAR.translatesAutoresizingMaskIntoConstraints = false
tutorialAR.activatesAutomatically = true
arView.addSubview(tutorialAR)

NSLayoutConstraint.activate([
    tutorialAR.centerXAnchor.constraint(equalTo: arView.centerXAnchor),
    tutorialAR.centerYAnchor.constraint(equalTo: arView.centerYAnchor),
    tutorialAR.widthAnchor.constraint(equalTo: arView.widthAnchor),
    tutorialAR.heightAnchor.constraint(equalTo: arView.heightAnchor)])

let realityFile = Bundle.main.url(forResource: "AirHockey", withExtension: "reality")
let boncyBallsScene = try! Entity.load(contentsOf: realityFile!)

let anchor = AnchorEntity(plane: .horizontal)
anchor.addChild(boncyBallsScene)
anchor.scale = [1,1,1]

arView.contentScaleFactor = 0.7
arView.scene.addAnchor(anchor)
arView.session.run(initialize)

NotificationCenter.default.addObserver(forName: UIApplication.didReceiveMemoryWarningNotification, object: nil, queue: nil) {
    _ in arView.contentScaleFactor = max(arView.contentScaleFactor, 0.05)
}



PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = arView
PlaygroundPage.current.wantsFullScreenLiveView = true

//#-end-hidden-code
